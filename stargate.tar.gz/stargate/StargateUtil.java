package stargate;


public class StargateUtil {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		boolean listening = false;
		int port = -1;

		if(args[0].equals("-listen"))
		{
			listening = true;
			port = Integer.parseInt(args[1]);
		}
		
		/* // Deprecated 
		else if(args[0].equals("-connect"))
		{
			listening = false;
			// form the URL
			Dialer d = new Dialer();
			d.Connect(args[1], Integer.parseInt(args[2]));
			
		}*/
		
		else
		{
			System.out.println("Unrecognized option" + args[0]);
			System.exit(1);
		}

		// Start up a server
		if(listening)
		{
			try
			{
				Thread t = new Dialee(port);
				t.start();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
	}
}

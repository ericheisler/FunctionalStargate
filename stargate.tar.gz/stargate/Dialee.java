package stargate;


//Adapted from http://www.tutorialspoint.com/java/java_networking.htm


import java.net.*;
import java.util.Random;
import java.io.*;

public class Dialee extends Thread
{
	private ServerSocket serverSocket;

	public Dialee(int port) throws IOException
	{
		
		// Try to print this machine's externally visible IP
		String ip = getInetAddr();
		if(ip.equals(""))
		{
			System.out.println("unable to detect local IP");
			//System.exit(1);
		}
		
		serverSocket = new ServerSocket(port);
		
		// 0 = no timeout, let gates connect whenever they want
		serverSocket.setSoTimeout(0); 

	}

	public void run()
	{
		Random r = new Random();
		
		// Run forever. Will reset and accept new connections after a successful dial
		while(true)
		{
			DataInputStream gateDialerIn = null;
			DataInputStream gateDialeeIn = null;
			DataOutputStream gateDialerOut = null;
			DataOutputStream gateDialeeOut = null;
			Socket server1 = null;
			Socket server2 = null;
			DataInputStream in1 = null;
			DataInputStream in2 = null;

			try
			{
				System.out.println("Waiting for dialer on port " + serverSocket.getLocalPort() + "...");
				System.out.println("Waiting for receiver on port " + serverSocket.getLocalPort() + "...");

				// Wait for 1st connection
				server1 = serverSocket.accept();
				
				// We have to open the stream before deciding what type of gate it is
				in1 = new DataInputStream(server1.getInputStream());
				byte gateType = in1.readByte(); // first byte is gate type
				
				if(gateType == 0)
				{
					System.out.println("Connected to dialer: " + server1.getRemoteSocketAddress());
					gateDialerIn = in1;
					gateDialerOut = new DataOutputStream(server1.getOutputStream());
				}
				else
				{
					System.out.println("Connected to dialee: " + server1.getRemoteSocketAddress());
					gateDialeeIn = in1;
					gateDialeeOut = new DataOutputStream(server1.getOutputStream());
				}


				// Now wait for the 2nd gate to connect 
				server2 = serverSocket.accept();
				in2 = new DataInputStream(server2.getInputStream());
				gateType = in2.readByte();// first byte is gate type
				
				if(gateType == 0)
				{
					if(gateDialerIn != null)
					{
						System.out.println("Error: two dialers connected");
						reset(in1, in2, gateDialerOut, server1, server2);
						continue;
					}
					System.out.println("Connected to dialer: " + server2.getRemoteSocketAddress());
					gateDialerIn = in2;
					gateDialerOut = new DataOutputStream(server2.getOutputStream());
				}
				else
				{
					if(gateDialeeIn != null)
					{
						System.out.println("Error: two dialees connected");
						reset(in1, in2, gateDialeeOut, server1, server2);
						continue;
					}
					System.out.println("Connected to dialee: " + server2.getRemoteSocketAddress());
					gateDialeeIn = in2;
					gateDialeeOut = new DataOutputStream(server2.getOutputStream());
				}

				// Tell the gates we're ready
				gateDialerOut.writeByte(255);
				gateDialeeOut.writeByte(255);

				
				// Transfer 7 chevrons
				// If we were connecting outside our own galaxy, 
				// such as somewhere in Pegasus, we would transfer 8
				for(int i=0; i < 7; i++)
				{
					int waitMilis = 0;
					while(gateDialerIn.available() < 1 && waitMilis < 60000)
					{
						waitMilis += 50;
						Thread.sleep(50);
					}
					if(waitMilis >= 60000)
					{
						System.out.println("dial timed out");
						break;
					}
					
					// Read the next chevron from the dialer
					byte nextChevron = gateDialerIn.readByte();
					//System.out.println("read glyph" + nextChevron);

					// Send the ack
					gateDialerOut.writeByte(nextChevron);

					// Send the chevron to the receiver
					gateDialeeOut.writeByte(nextChevron);
					//System.out.println("server sending " + nextChevron);
				}

				reset(in1, in2, gateDialeeOut, server1, server2);

			}
			
			// Not gonna do anything special with exceptions
			catch(SocketTimeoutException s)
			{
				System.out.println("Socket timed out!");
				reset(in1, in2, gateDialeeOut, server1, server2);
				continue;
			}
			catch(IOException e)
			{
				e.printStackTrace();
				reset(in1, in2, gateDialeeOut, server1, server2);
				continue;
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				reset(in1, in2, gateDialeeOut, server1, server2);
				e.printStackTrace();
				continue;
			}
		}
	}

	// Closes input/output streams and sockets
	public void reset(DataInputStream in1, DataInputStream in2, DataOutputStream out, Socket s1, Socket s2)
	{
		try
		{	
			if(in1 != null)
				in1.close();
			if(in2 != null)
				in2.close();
			if(out != null)
				out.close();
			if(s1 != null)
				s1.close();
			if(s2 != null)
				s2.close();
		}
		catch(IOException e)
		{e.printStackTrace();}
	}

	// Gets this machines externally visible IP
	public static String getInetAddr()
	{
		URL whatismyip;
		try {
			whatismyip = new URL("http://icanhazip.com");

			BufferedReader in = new BufferedReader(new InputStreamReader(
					whatismyip.openStream()));

			String ip = in.readLine(); 
			System.out.println("ip = " + ip);
			return ip;

		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return "";
	}

}
